


module video_out (
    input wire        I_rst_n,

    input wire        I_ddr_clk,
    output wire       O_video_out_rd_busy,  
    input wire        I_video_in_wr_busy,   
    input wire[1:0]   I_video_out_rp,
    input wire[11:0]   I_slot_modes,
    output reg[2:0]   O_frame_mode,
    output wire       O_ddr_user_rd_en,
    output reg[24:0]  O_ddr_user_addr,
    input wire        I_ddr_user_ready,
    input wire        I_ddr_user_rd_valid,
    input wire[127:0] I_ddr_user_rd_data,

    input wire        I_dsi_clk,
    input wire        I_video_vsync,
    input wire        I_video_rd_en,  
    output reg[23:0]  O_vdieo_data
);

    localparam CROP_OFFSET = 25'd115392; // ((60*1280+128)*3)/2
    localparam ROW_SKIP = 25'd384; // (1280-1024)*3/2, in 16-bit address units
    reg [7:0] S_crop_word;
    reg [9:0] S_crop_row;
    reg [9:0] S_outstanding_reads;
    reg S_frame_pending;
    reg S_frame_ready;
    reg         S_fifo_rst;     
    wire S_flush_start = S_frame_pending && (S_outstanding_reads == 0) && !S_fifo_rst;
    reg[7:0]    S_fifo_rst_cnt;
    wire[8:0]   S_fifo_wr_num;       
    wire        S_fifo_rd_en;        
    wire[127:0] S_fifo_rd_data;      
    reg         S_video_vsync_1d;
    reg         S_video_vsync_2d;
    reg         S_video_vsync_3d;
    wire        S_video_frame_start;   
    wire        S_ddr_rd_trig;       
    reg         S_ddr_rd_valid;      
    reg[9:0]    S_ddr_rd_cnt;        
    reg[3:0]    S_fifo_rd_cnt;       
    reg         S_video_rd_en_1d;
    reg[3:0]    S_fifo_rd_cnt_1d;     
    reg[127:0]  S_fifo_rd_data_1d;    
	wire        S_fifo_emtpy;     



    // Capture the selected slot's mode on the same edge as its read address.
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n) O_frame_mode<=0;
        else if(S_video_frame_start) O_frame_mode<=I_slot_modes[I_video_out_rp*3 +: 3];
    end

    localparam IMAGE_BASE_ADDR_0 = 25'd0;
    localparam IMAGE_BASE_ADDR_1 = 25'd7000000;
    localparam IMAGE_BASE_ADDR_2 = 25'd14000000;
    localparam IMAGE_BASE_ADDR_3 = 25'd21000000;


    always @(posedge I_ddr_clk) begin
        S_video_vsync_1d <= I_video_vsync;
        S_video_vsync_2d <=S_video_vsync_1d;
        S_video_vsync_3d <= S_video_vsync_2d;
    end

    assign S_video_frame_start = ~S_video_vsync_3d & S_video_vsync_2d;


    // Drain any previous frame's queued DDR reads before resetting the FIFO.
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_outstanding_reads <= 0;
            S_frame_pending <= 0;
            S_frame_ready <= 0;
            S_fifo_rst <= 0;
            S_fifo_rst_cnt <= 0;
        end else begin
            case ({O_ddr_user_rd_en, I_ddr_user_rd_valid})
                2'b10: S_outstanding_reads <= S_outstanding_reads + 1'b1;
                2'b01: S_outstanding_reads <= S_outstanding_reads - 1'b1;
                default: S_outstanding_reads <= S_outstanding_reads;
            endcase
            if (S_video_frame_start) begin
                S_frame_pending <= 1;
                S_frame_ready <= 0;
            end
            if (S_flush_start) begin
                S_fifo_rst <= 1;
                S_fifo_rst_cnt <= 0;
                S_frame_pending <= 0;
            end else if (S_fifo_rst) begin
                if (S_fifo_rst_cnt == 8'd10) begin
                    S_fifo_rst <= 0;
                    S_frame_ready <= 1;
                end else S_fifo_rst_cnt <= S_fifo_rst_cnt + 1'b1;
            end
        end
    end

    /*
        这里需要注意fifo的剩余空间一定要大于将要写入的长度，因为ddr读出的时候会有至少40个时钟周期的延时，
        例如每次从ddr读出240个长度的数据，那么fifo的剩余空间最少要设为280，否则会引起fifo写满丢失数据。
    */
    assign S_ddr_rd_trig = (('d511 - S_fifo_wr_num) >= 'd300) && (!I_video_in_wr_busy) && (!S_ddr_rd_valid) && (!S_fifo_rst) && I_rst_n && S_frame_ready && !S_video_frame_start && (S_crop_row < 600) ? 1'b1 : 1'b0;

    /*
        fifo的深度是512，实际的深度是510，因此需要注意每次读出的长度避免为256，否则连续两次写入会引起fifo写满，丢失数据
    */
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_ddr_rd_valid <= 1'b0;
        else
			if(S_video_frame_start || S_frame_pending || (O_ddr_user_rd_en && S_ddr_rd_cnt == 'd191))
                S_ddr_rd_valid <= 1'b0;
            else if(S_ddr_rd_trig)
                S_ddr_rd_valid <= 1'b1;
            else
                S_ddr_rd_valid <= S_ddr_rd_valid;
    end

    assign O_ddr_user_rd_en = S_ddr_rd_valid & I_ddr_user_ready & S_frame_ready & ~S_video_frame_start;

    always @(posedge I_ddr_clk) begin
        if(S_ddr_rd_valid && !S_video_frame_start)
            begin
                if(O_ddr_user_rd_en)
                    S_ddr_rd_cnt <= S_ddr_rd_cnt + 'd1;
                else
                    S_ddr_rd_cnt <= S_ddr_rd_cnt;
            end
        else    
            S_ddr_rd_cnt <= 'd0;
    end


    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            O_ddr_user_addr <= 'd0;
        else
            if(S_video_frame_start)
                begin
                    case(I_video_out_rp)
                        'd0: O_ddr_user_addr <= IMAGE_BASE_ADDR_0 + CROP_OFFSET;
                        'd1: O_ddr_user_addr <= IMAGE_BASE_ADDR_1 + CROP_OFFSET;
                        'd2: O_ddr_user_addr <= IMAGE_BASE_ADDR_2 + CROP_OFFSET;
                        'd3: O_ddr_user_addr <= IMAGE_BASE_ADDR_3 + CROP_OFFSET;
                    endcase
                end
            else if(O_ddr_user_rd_en)
                O_ddr_user_addr <= O_ddr_user_addr + 25'd8 +
                                   ((S_crop_word == 191) ? ROW_SKIP : 25'd0);
            else    
                O_ddr_user_addr <= O_ddr_user_addr;
    end

    
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin S_crop_word <= 0; S_crop_row <= 0; end
        else if (S_video_frame_start) begin S_crop_word <= 0; S_crop_row <= 0; end
        else if (O_ddr_user_rd_en) begin
            if (S_crop_word == 191) begin
                S_crop_word <= 0;
                S_crop_row <= S_crop_row + 1'b1;
            end else S_crop_word <= S_crop_word + 1'b1;
        end
    end

    assign O_video_out_rd_busy = S_ddr_rd_trig | S_ddr_rd_valid;


    w128_d512_fifo U_w128_d512_fifo(
        .rst        ( S_fifo_rst          ),   

        .clkw       ( I_ddr_clk           ),     
        .we         ( I_ddr_user_rd_valid ),
        .di         ( I_ddr_user_rd_data  ),
        .wrusedw    ( S_fifo_wr_num       ),
        .afull      (),
        .full_flag  (),
 
        .clkr       ( I_dsi_clk           ),
        .re         ( S_fifo_rd_en        ), 
        .dout       ( S_fifo_rd_data      ),  
        .rdusedw    (), 
        .valid      (),  
        .empty_flag ( S_fifo_emtpy        ),
        .aempty     ()
    );


   always @(posedge I_dsi_clk) begin
       if(I_video_rd_en)
           S_fifo_rd_cnt <= S_fifo_rd_cnt + 'd1;
       else
           S_fifo_rd_cnt <= 'd0;
   end

   assign S_fifo_rd_en = I_video_rd_en && (S_fifo_rd_cnt == 'd0)  ? 1'b1 :
                         I_video_rd_en && (S_fifo_rd_cnt == 'd5)  ? 1'b1 :
                         I_video_rd_en && (S_fifo_rd_cnt == 'd10) ? 1'b1 : 1'b0;

   always @(posedge I_dsi_clk) begin
       S_video_rd_en_1d  <= I_video_rd_en;
       S_fifo_rd_cnt_1d  <= S_fifo_rd_cnt;
       S_fifo_rd_data_1d <= S_fifo_rd_data;
   end

   always @(posedge I_dsi_clk) begin
       if(S_video_rd_en_1d)
           begin
               case(S_fifo_rd_cnt_1d)
                   'd0: O_vdieo_data  <= S_fifo_rd_data[127:104];
                   'd1: O_vdieo_data  <= S_fifo_rd_data[103:80];
                   'd2: O_vdieo_data  <= S_fifo_rd_data[79:56];
                   'd3: O_vdieo_data  <= S_fifo_rd_data[55:32];
                   'd4: O_vdieo_data  <= S_fifo_rd_data[31:8];
                   'd5: O_vdieo_data  <= {S_fifo_rd_data_1d[7:0],S_fifo_rd_data[127:112]};
                   'd6: O_vdieo_data  <= S_fifo_rd_data[111:88];
                   'd7: O_vdieo_data  <= S_fifo_rd_data[87:64];
                   'd8: O_vdieo_data  <= S_fifo_rd_data[63:40];
                   'd9: O_vdieo_data  <= S_fifo_rd_data[39:16];
                   'd10: O_vdieo_data <= {S_fifo_rd_data_1d[15:0],S_fifo_rd_data[127:120]};
                   'd11: O_vdieo_data <= S_fifo_rd_data[119:96];
                   'd12: O_vdieo_data <= S_fifo_rd_data[95:72];
                   'd13: O_vdieo_data <= S_fifo_rd_data[71:48];
                   'd14: O_vdieo_data <= S_fifo_rd_data[47:24];
                   'd15: O_vdieo_data <= S_fifo_rd_data[23:0];
               endcase
           end
       else
           O_vdieo_data <= 'd0;
   end

    
endmodule
